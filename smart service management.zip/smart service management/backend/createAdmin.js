const bcrypt = require('bcryptjs');
const db = require('./db');

async function createAdmin() {

    try {

        const name = 'System Admin';
        const email = 'admin@smartservice.com';
        const phone = '9999999999';
        const password = 'admin123';

        // Check if admin already exists
        const [existing] = await db.query(
            'SELECT user_id FROM users WHERE email = ?',
            [email]
        );

        if (existing.length > 0) {

            console.log('Admin already exists.');

            process.exit();

        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Insert admin
        await db.query(
            `INSERT INTO users
            (name, email, phone, password, role)
            VALUES (?, ?, ?, ?, 'admin')`,
            [
                name,
                email,
                phone,
                hashedPassword
            ]
        );

        console.log('Admin created successfully!');
        console.log('');
        console.log('Email:', email);
        console.log('Password:', password);

        process.exit();

    } catch (error) {

        console.error('Error creating admin:', error);

        process.exit(1);

    }

}

createAdmin();