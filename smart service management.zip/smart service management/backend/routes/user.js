const express = require('express');
const db = require('../db');

const router = express.Router();


// =====================================================
// USER DASHBOARD STATISTICS
// =====================================================

router.get('/dashboard-stats/:userId', async (req, res) => {

    try {

        const userId = req.params.userId;


        // Total requests
        const [total] = await db.query(
            `SELECT COUNT(*) AS total
             FROM service_requests
             WHERE user_id = ?`,
            [userId]
        );


        // Active requests
        const [active] = await db.query(
            `SELECT COUNT(*) AS total
             FROM service_requests
             WHERE user_id = ?
             AND status IN (
                 'Pending',
                 'Accepted',
                 'Assigned',
                 'In Progress'
             )`,
            [userId]
        );


        // Completed services
        const [completed] = await db.query(
            `SELECT COUNT(*) AS total
             FROM service_requests
             WHERE user_id = ?
             AND status = 'Completed'`,
            [userId]
        );


        res.json({

            myRequests: total[0].total,

            activeRequests: active[0].total,

            completedServices: completed[0].total

        });


    } catch (error) {

        console.error(
            'User dashboard error:',
            error
        );


        res.status(500).json({

            message:
                'Failed to load user dashboard'

        });

    }

});


// =====================================================
// GET USER PROFILE
// =====================================================

router.get('/profile/:userId', async (req, res) => {

    try {

        const userId = req.params.userId;


        const [users] = await db.query(
            `SELECT
                user_id,
                name,
                email,
                phone,
                role,
                default_address,
                created_at
             FROM users
             WHERE user_id = ?`,
            [userId]
        );


        if (users.length === 0) {

            return res.status(404).json({

                message: 'User not found'

            });

        }


        res.json(users[0]);


    } catch (error) {

        console.error(
            'Profile error:',
            error
        );


        res.status(500).json({

            message:
                'Failed to load profile'

        });

    }

});


// =====================================================
// GET USER ADDRESSES
// =====================================================

router.get('/addresses/:userId', async (req, res) => {

    try {

        const userId = req.params.userId;


        const [addresses] = await db.query(
            `SELECT
                address_id,
                user_id,
                address,
                latitude,
                longitude,
                is_default
             FROM addresses
             WHERE user_id = ?
             ORDER BY is_default DESC, address_id DESC`,
            [userId]
        );


        res.json(addresses);


    } catch (error) {

        console.error(
            'Get addresses error:',
            error
        );


        res.status(500).json({

            message:
                'Failed to load addresses'

        });

    }

});


// =====================================================
// ADD USER ADDRESS
// =====================================================

router.post('/addresses/:userId', async (req, res) => {

    try {

        const userId = req.params.userId;

        const {
            address,
            latitude,
            longitude,
            is_default
        } = req.body;


        // Check address
        if (!address || !address.trim()) {

            return res.status(400).json({

                message:
                    'Address is required'

            });

        }


        // Check user
        const [users] = await db.query(
            `SELECT user_id
             FROM users
             WHERE user_id = ?`,
            [userId]
        );


        if (users.length === 0) {

            return res.status(404).json({

                message:
                    'User not found'

            });

        }


        // If this address should be default,
        // remove default from other addresses.
        if (is_default === true) {

            await db.query(
                `UPDATE addresses
                 SET is_default = FALSE
                 WHERE user_id = ?`,
                [userId]
            );

        }


        const [result] = await db.query(
            `INSERT INTO addresses
            (
                user_id,
                address,
                latitude,
                longitude,
                is_default
            )
            VALUES (?, ?, ?, ?, ?)`,
            [
                userId,
                address.trim(),
                latitude || null,
                longitude || null,
                is_default === true
            ]
        );


        // If this is the first address,
        // automatically make it default.
        const [addressCount] = await db.query(
            `SELECT COUNT(*) AS total
             FROM addresses
             WHERE user_id = ?`,
            [userId]
        );


        if (addressCount[0].total === 1) {

            await db.query(
                `UPDATE addresses
                 SET is_default = TRUE
                 WHERE address_id = ?`,
                [result.insertId]
            );

        }


        res.status(201).json({

            message:
                'Address added successfully',

            address_id:
                result.insertId

        });


    } catch (error) {

        console.error(
            'Add address error:',
            error
        );


        res.status(500).json({

            message:
                'Failed to add address'

        });

    }

});


// =====================================================
// SET DEFAULT ADDRESS
// =====================================================

router.put(
    '/addresses/:userId/:addressId/default',
    async (req, res) => {

        try {

            const userId =
                req.params.userId;

            const addressId =
                req.params.addressId;


            // Check address belongs to user
            const [addresses] = await db.query(
                `SELECT address_id
                 FROM addresses
                 WHERE address_id = ?
                 AND user_id = ?`,
                [
                    addressId,
                    userId
                ]
            );


            if (addresses.length === 0) {

                return res.status(404).json({

                    message:
                        'Address not found'

                });

            }


            // Remove old default
            await db.query(
                `UPDATE addresses
                 SET is_default = FALSE
                 WHERE user_id = ?`,
                [userId]
            );


            // Set new default
            await db.query(
                `UPDATE addresses
                 SET is_default = TRUE
                 WHERE address_id = ?
                 AND user_id = ?`,
                [
                    addressId,
                    userId
                ]
            );


            res.json({

                message:
                    'Default address updated'

            });


        } catch (error) {

            console.error(
                'Default address error:',
                error
            );


            res.status(500).json({

                message:
                    'Failed to update default address'

            });

        }

    }
);


// =====================================================
// GET USER SERVICE REQUESTS
// =====================================================

router.get(
    '/service-requests/:userId',
    async (req, res) => {

        try {

            const userId =
                req.params.userId;


            const [requests] = await db.query(
                `SELECT
                    sr.request_id,
                    sr.user_id,
                    sr.service_id,
                    s.service_name,
                    s.skill_required,
                    sr.address_id,
                    a.address,
                    sr.description,
                    sr.priority,
                    sr.status,
                    sr.charge,
                    sr.created_at
                 FROM service_requests sr

                 INNER JOIN services s
                    ON sr.service_id = s.service_id

                 INNER JOIN addresses a
                    ON sr.address_id = a.address_id

                 WHERE sr.user_id = ?

                 ORDER BY sr.created_at DESC`,
                [userId]
            );


            res.json(requests);


        } catch (error) {

            console.error(
                'Get service requests error:',
                error
            );


            res.status(500).json({

                message:
                    'Failed to load service requests'

            });

        }

    }
);


// =====================================================
// CREATE SERVICE REQUEST
// =====================================================

router.post(
    '/service-requests',
    async (req, res) => {

        try {

            const {
                user_id,
                service_id,
                address_id,
                description,
                priority
            } = req.body;


            // =================================================
            // VALIDATE REQUIRED FIELDS
            // =================================================

            if (
                !user_id ||
                !service_id ||
                !address_id
            ) {

                return res.status(400).json({

                    message:
                        'User, service and address are required'

                });

            }


            // =================================================
            // CHECK USER
            // =================================================

            const [users] = await db.query(
                `SELECT user_id
                 FROM users
                 WHERE user_id = ?
                 AND role = 'user'`,
                [user_id]
            );


            if (users.length === 0) {

                return res.status(404).json({

                    message:
                        'User not found'

                });

            }


            // =================================================
            // CHECK SERVICE
            // =================================================

            const [services] = await db.query(
                `SELECT
                    service_id,
                    base_charge,
                    status
                 FROM services
                 WHERE service_id = ?`,
                [service_id]
            );


            if (services.length === 0) {

                return res.status(404).json({

                    message:
                        'Service not found'

                });

            }


            const service =
                services[0];


            // User can only request active service
            if (service.status !== 'Active') {

                return res.status(400).json({

                    message:
                        'This service is currently unavailable'

                });

            }


            // =================================================
            // CHECK ADDRESS
            // =================================================

            const [addresses] = await db.query(
                `SELECT address_id
                 FROM addresses
                 WHERE address_id = ?
                 AND user_id = ?`,
                [
                    address_id,
                    user_id
                ]
            );


            if (addresses.length === 0) {

                return res.status(400).json({

                    message:
                        'Invalid address selected'

                });

            }


            // =================================================
            // VALIDATE PRIORITY
            // =================================================

            const allowedPriorities = [
                'Low',
                'Medium',
                'High',
                'Emergency'
            ];


            const selectedPriority =
                priority || 'Medium';


            if (
                !allowedPriorities.includes(
                    selectedPriority
                )
            ) {

                return res.status(400).json({

                    message:
                        'Invalid priority'

                });

            }


            // =================================================
            // CREATE REQUEST
            // =================================================

            const [result] = await db.query(
                `INSERT INTO service_requests
                (
                    user_id,
                    service_id,
                    address_id,
                    description,
                    priority,
                    status,
                    charge
                )
                VALUES (?, ?, ?, ?, ?, 'Pending', ?)`,
                [
                    user_id,
                    service_id,
                    address_id,
                    description || null,
                    selectedPriority,
                    service.base_charge
                ]
            );


            res.status(201).json({

                message:
                    'Service request created successfully',

                request: {

                    request_id:
                        result.insertId,

                    user_id:
                        user_id,

                    service_id:
                        service_id,

                    address_id:
                        address_id,

                    priority:
                        selectedPriority,

                    status:
                        'Pending',

                    charge:
                        service.base_charge

                }

            });


        } catch (error) {

            console.error(
                'Create service request error:',
                error
            );


            res.status(500).json({

                message:
                    'Failed to create service request'

            });

        }

    }
);


// =====================================================
// CANCEL SERVICE REQUEST
// =====================================================

router.put(
    '/service-requests/:requestId/cancel',
    async (req, res) => {

        try {

            const requestId =
                req.params.requestId;

            const {
                user_id
            } = req.body;


            if (!user_id) {

                return res.status(400).json({

                    message:
                        'User ID is required'

                });

            }


            const [requests] = await db.query(
                `SELECT
                    request_id,
                    status
                 FROM service_requests
                 WHERE request_id = ?
                 AND user_id = ?`,
                [
                    requestId,
                    user_id
                ]
            );


            if (requests.length === 0) {

                return res.status(404).json({

                    message:
                        'Service request not found'

                });

            }


            const request =
                requests[0];


            if (
                request.status === 'Completed' ||
                request.status === 'Cancelled'
            ) {

                return res.status(400).json({

                    message:
                        'This request cannot be cancelled'

                });

            }


            await db.query(
                `UPDATE service_requests
                 SET status = 'Cancelled'
                 WHERE request_id = ?
                 AND user_id = ?`,
                [
                    requestId,
                    user_id
                ]
            );


            res.json({

                message:
                    'Service request cancelled successfully'

            });


        } catch (error) {

            console.error(
                'Cancel request error:',
                error
            );


            res.status(500).json({

                message:
                    'Failed to cancel service request'

            });

        }

    }
);


module.exports = router;