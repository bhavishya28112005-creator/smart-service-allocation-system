const express = require('express');
const db = require('../db');

const router = express.Router();


// =====================================================
// GET ACTIVE SERVICES
// Used by users when requesting a service
// =====================================================

router.get('/', async (req, res) => {

    try {

        const [services] = await db.query(`
            SELECT
                service_id,
                service_name,
                description,
                skill_required,
                base_charge,
                estimated_time,
                status
            FROM services
            WHERE status = 'Active'
            ORDER BY service_name ASC
        `);


        res.json(services);

    } catch (error) {

        console.error('Get services error:', error);

        res.status(500).json({
            message: 'Failed to load services'
        });

    }

});


// =====================================================
// GET ALL SERVICES
// Used by Admin
// Includes Active and Inactive services
// =====================================================

router.get('/all', async (req, res) => {

    try {

        const [services] = await db.query(`
            SELECT
                service_id,
                service_name,
                description,
                skill_required,
                base_charge,
                estimated_time,
                status,
                created_at
            FROM services
            ORDER BY service_id DESC
        `);


        res.json(services);

    } catch (error) {

        console.error('Get all services error:', error);

        res.status(500).json({
            message: 'Failed to load all services'
        });

    }

});


// =====================================================
// ADD NEW SERVICE
// =====================================================

router.post('/', async (req, res) => {

    try {

        const {
            service_name,
            description,
            skill_required,
            base_charge,
            estimated_time
        } = req.body;


        // Check required fields
        if (
            !service_name ||
            !skill_required ||
            base_charge === undefined ||
            base_charge === null
        ) {

            return res.status(400).json({
                message:
                    'Service name, skill required and base charge are required'
            });

        }


        // Validate charge
        if (Number(base_charge) < 0) {

            return res.status(400).json({
                message: 'Base charge cannot be negative'
            });

        }


        // Validate estimated time
        if (
            estimated_time !== undefined &&
            estimated_time !== null &&
            Number(estimated_time) < 0
        ) {

            return res.status(400).json({
                message: 'Estimated time cannot be negative'
            });

        }


        // Check duplicate service name
        const [existing] = await db.query(
            `SELECT service_id
             FROM services
             WHERE service_name = ?`,
            [service_name]
        );


        if (existing.length > 0) {

            return res.status(400).json({
                message: 'Service with this name already exists'
            });

        }


        // Insert service
        const [result] = await db.query(
            `INSERT INTO services
            (
                service_name,
                description,
                skill_required,
                base_charge,
                estimated_time,
                status
            )
            VALUES (?, ?, ?, ?, ?, 'Active')`,
            [
                service_name,
                description || null,
                skill_required,
                Number(base_charge),
                estimated_time || null
            ]
        );


        res.status(201).json({

            message: 'Service added successfully',

            service: {
                service_id: result.insertId,
                service_name: service_name,
                description: description || null,
                skill_required: skill_required,
                base_charge: Number(base_charge),
                estimated_time: estimated_time || null,
                status: 'Active'
            }

        });

    } catch (error) {

        console.error('Add service error:', error);

        res.status(500).json({
            message: 'Failed to add service'
        });

    }

});


// =====================================================
// UPDATE SERVICE
// =====================================================

router.put('/:id', async (req, res) => {

    try {

        const serviceId = req.params.id;

        const {
            service_name,
            description,
            skill_required,
            base_charge,
            estimated_time,
            status
        } = req.body;


        // Check service exists
        const [existing] = await db.query(
            `SELECT *
             FROM services
             WHERE service_id = ?`,
            [serviceId]
        );


        if (existing.length === 0) {

            return res.status(404).json({
                message: 'Service not found'
            });

        }


        // Validate required fields
        if (
            !service_name ||
            !skill_required ||
            base_charge === undefined ||
            base_charge === null
        ) {

            return res.status(400).json({
                message:
                    'Service name, skill required and base charge are required'
            });

        }


        // Validate charge
        if (Number(base_charge) < 0) {

            return res.status(400).json({
                message: 'Base charge cannot be negative'
            });

        }


        // Validate estimated time
        if (
            estimated_time !== undefined &&
            estimated_time !== null &&
            Number(estimated_time) < 0
        ) {

            return res.status(400).json({
                message: 'Estimated time cannot be negative'
            });

        }


        // Validate status
        let serviceStatus = status || existing[0].status;

        if (
            serviceStatus !== 'Active' &&
            serviceStatus !== 'Inactive'
        ) {

            return res.status(400).json({
                message: 'Invalid service status'
            });

        }


        // Check duplicate name
        const [duplicate] = await db.query(
            `SELECT service_id
             FROM services
             WHERE service_name = ?
             AND service_id != ?`,
            [
                service_name,
                serviceId
            ]
        );


        if (duplicate.length > 0) {

            return res.status(400).json({
                message: 'Another service with this name already exists'
            });

        }


        // Update service
        await db.query(
            `UPDATE services
             SET
                service_name = ?,
                description = ?,
                skill_required = ?,
                base_charge = ?,
                estimated_time = ?,
                status = ?
             WHERE service_id = ?`,
            [
                service_name,
                description || null,
                skill_required,
                Number(base_charge),
                estimated_time || null,
                serviceStatus,
                serviceId
            ]
        );


        res.json({

            message: 'Service updated successfully'

        });

    } catch (error) {

        console.error('Update service error:', error);

        res.status(500).json({
            message: 'Failed to update service'
        });

    }

});


// =====================================================
// DELETE SERVICE
// =====================================================
// We do NOT physically delete the service.
// Instead, we mark it as Inactive.
//
// This is safer because service_requests may already
// contain references to this service.
// =====================================================

router.delete('/:id', async (req, res) => {

    try {

        const serviceId = req.params.id;


        // Check service exists
        const [existing] = await db.query(
            `SELECT service_id
             FROM services
             WHERE service_id = ?`,
            [serviceId]
        );


        if (existing.length === 0) {

            return res.status(404).json({
                message: 'Service not found'
            });

        }


        // Mark as inactive
        await db.query(
            `UPDATE services
             SET status = 'Inactive'
             WHERE service_id = ?`,
            [serviceId]
        );


        res.json({

            message: 'Service deactivated successfully'

        });

    } catch (error) {

        console.error('Delete service error:', error);

        res.status(500).json({
            message: 'Failed to deactivate service'
        });

    }

});


module.exports = router;