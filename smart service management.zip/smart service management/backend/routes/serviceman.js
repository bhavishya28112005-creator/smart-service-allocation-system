const express = require('express');

const db = require('../db');

const router = express.Router();

/*
====================================================
GET SERVICEMAN DASHBOARD STATS
====================================================
*/
router.get('/dashboard-stats/:servicemanId', async (req, res) => {
    try {
        const { servicemanId } = req.params;

        const [result] = await db.query(
            `
            SELECT
                COUNT(*) AS total_assigned,

                SUM(
                    CASE
                        WHEN sr.status = 'In Progress'
                        THEN 1
                        ELSE 0
                    END
                ) AS in_progress,

                SUM(
                    CASE
                        WHEN sr.status = 'Completed'
                        THEN 1
                        ELSE 0
                    END
                ) AS completed,

                SUM(
                    CASE
                        WHEN sr.status IN ('Assigned', 'Accepted')
                        THEN 1
                        ELSE 0
                    END
                ) AS pending

            FROM assignments a

            INNER JOIN service_requests sr
                ON a.request_id = sr.request_id

            WHERE a.serviceman_id = ?
            `,
            [servicemanId]
        );

        res.json({
            total_assigned: Number(result[0].total_assigned || 0),
            pending: Number(result[0].pending || 0),
            in_progress: Number(result[0].in_progress || 0),
            completed: Number(result[0].completed || 0)
        });

    } catch (error) {
        console.error(
            'Serviceman dashboard stats error:',
            error
        );

        res.status(500).json({
            message: 'Server error'
        });
    }
});


/*
====================================================
GET ASSIGNED REQUESTS
====================================================
*/
router.get('/requests/:servicemanId', async (req, res) => {
    try {
        const { servicemanId } = req.params;

        const [requests] = await db.query(
            `
            SELECT
                sr.request_id,
                sr.description,
                sr.priority,
                sr.status,
                sr.charge,
                sr.created_at,

                s.service_name,
                s.description AS service_description,
                s.skill_required,
                s.estimated_time,

                u.name AS customer_name,
                u.phone AS customer_phone,
                u.email AS customer_email,

                a.address,

                ass.assignment_id,
                ass.assigned_at,
                ass.started_at,
                ass.completed_at

            FROM assignments ass

            INNER JOIN service_requests sr
                ON ass.request_id = sr.request_id

            INNER JOIN services s
                ON sr.service_id = s.service_id

            INNER JOIN users u
                ON sr.user_id = u.user_id

            INNER JOIN addresses a
                ON sr.address_id = a.address_id

            WHERE ass.serviceman_id = ?

            ORDER BY
                CASE
                    WHEN sr.status = 'Assigned' THEN 1
                    WHEN sr.status = 'In Progress' THEN 2
                    WHEN sr.status = 'Completed' THEN 3
                    ELSE 4
                END,
                sr.created_at DESC
            `,
            [servicemanId]
        );

        res.json(requests);

    } catch (error) {
        console.error(
            'Get serviceman requests error:',
            error
        );

        res.status(500).json({
            message: 'Server error'
        });
    }
});


/*
====================================================
GET SINGLE ASSIGNED REQUEST
====================================================
*/
router.get('/requests/:servicemanId/:requestId', async (req, res) => {
    try {
        const {
            servicemanId,
            requestId
        } = req.params;

        const [requests] = await db.query(
            `
            SELECT
                sr.request_id,
                sr.description,
                sr.priority,
                sr.status,
                sr.charge,
                sr.created_at,

                s.service_name,
                s.description AS service_description,
                s.skill_required,
                s.estimated_time,

                u.name AS customer_name,
                u.phone AS customer_phone,
                u.email AS customer_email,

                a.address,
                a.latitude,
                a.longitude,

                ass.assignment_id,
                ass.assigned_at,
                ass.started_at,
                ass.completed_at

            FROM assignments ass

            INNER JOIN service_requests sr
                ON ass.request_id = sr.request_id

            INNER JOIN services s
                ON sr.service_id = s.service_id

            INNER JOIN users u
                ON sr.user_id = u.user_id

            INNER JOIN addresses a
                ON sr.address_id = a.address_id

            WHERE ass.serviceman_id = ?
            AND sr.request_id = ?
            `,
            [
                servicemanId,
                requestId
            ]
        );

        if (requests.length === 0) {
            return res.status(404).json({
                message: 'Request not found'
            });
        }

        res.json(requests[0]);

    } catch (error) {
        console.error(
            'Get single serviceman request error:',
            error
        );

        res.status(500).json({
            message: 'Server error'
        });
    }
});


/*
====================================================
START JOB
Assigned → In Progress
====================================================
*/
router.put(
    '/requests/:requestId/start',
    async (req, res) => {

        const connection = await db.getConnection();

        try {
            const { requestId } = req.params;
            const { servicemanId } = req.body;

            if (!servicemanId) {
                return res.status(400).json({
                    message: 'Serviceman ID is required'
                });
            }

            await connection.beginTransaction();

            const [assignments] = await connection.query(
                `
                SELECT *
                FROM assignments
                WHERE request_id = ?
                AND serviceman_id = ?
                FOR UPDATE
                `,
                [
                    requestId,
                    servicemanId
                ]
            );

            if (assignments.length === 0) {
                await connection.rollback();

                return res.status(404).json({
                    message: 'Assignment not found'
                });
            }

            const assignment = assignments[0];

            const [requests] = await connection.query(
                `
                SELECT *
                FROM service_requests
                WHERE request_id = ?
                FOR UPDATE
                `,
                [requestId]
            );

            if (requests.length === 0) {
                await connection.rollback();

                return res.status(404).json({
                    message: 'Service request not found'
                });
            }

            const request = requests[0];

            if (request.status === 'Completed') {
                await connection.rollback();

                return res.status(400).json({
                    message: 'This job is already completed'
                });
            }

            if (request.status === 'In Progress') {
                await connection.rollback();

                return res.status(400).json({
                    message: 'This job is already in progress'
                });
            }

            if (request.status !== 'Assigned') {
                await connection.rollback();

                return res.status(400).json({
                    message:
                        'Only assigned jobs can be started'
                });
            }

            await connection.query(
                `
                UPDATE assignments
                SET started_at = NOW()
                WHERE assignment_id = ?
                `,
                [assignment.assignment_id]
            );

            await connection.query(
                `
                UPDATE service_requests
                SET status = 'In Progress'
                WHERE request_id = ?
                `,
                [requestId]
            );

            await connection.commit();

            res.json({
                message: 'Job started successfully'
            });

        } catch (error) {

            await connection.rollback();

            console.error(
                'Start job error:',
                error
            );

            res.status(500).json({
                message: 'Server error while starting job'
            });

        } finally {
            connection.release();
        }
    }
);


/*
====================================================
COMPLETE JOB
In Progress → Completed
====================================================
*/
router.put(
    '/requests/:requestId/complete',
    async (req, res) => {

        const connection = await db.getConnection();

        try {
            const { requestId } = req.params;
            const { servicemanId } = req.body;

            if (!servicemanId) {
                return res.status(400).json({
                    message: 'Serviceman ID is required'
                });
            }

            await connection.beginTransaction();

            const [assignments] = await connection.query(
                `
                SELECT *
                FROM assignments
                WHERE request_id = ?
                AND serviceman_id = ?
                FOR UPDATE
                `,
                [
                    requestId,
                    servicemanId
                ]
            );

            if (assignments.length === 0) {
                await connection.rollback();

                return res.status(404).json({
                    message: 'Assignment not found'
                });
            }

            const assignment = assignments[0];

            const [requests] = await connection.query(
                `
                SELECT *
                FROM service_requests
                WHERE request_id = ?
                FOR UPDATE
                `,
                [requestId]
            );

            if (requests.length === 0) {
                await connection.rollback();

                return res.status(404).json({
                    message: 'Service request not found'
                });
            }

            const request = requests[0];

            if (request.status === 'Completed') {
                await connection.rollback();

                return res.status(400).json({
                    message: 'This job is already completed'
                });
            }

            if (request.status !== 'In Progress') {
                await connection.rollback();

                return res.status(400).json({
                    message:
                        'Only jobs in progress can be completed'
                });
            }

            /*
            --------------------------------------------
            Update assignment completion time
            --------------------------------------------
            */

            await connection.query(
                `
                UPDATE assignments
                SET completed_at = NOW()
                WHERE assignment_id = ?
                `,
                [assignment.assignment_id]
            );


            /*
            --------------------------------------------
            Update service request
            --------------------------------------------
            */

            await connection.query(
                `
                UPDATE service_requests
                SET status = 'Completed'
                WHERE request_id = ?
                `,
                [requestId]
            );


            /*
            --------------------------------------------
            Reduce serviceman workload
            --------------------------------------------
            */

            await connection.query(
                `
                UPDATE servicemen
                SET current_workload =
                    CASE
                        WHEN current_workload > 0
                        THEN current_workload - 1
                        ELSE 0
                    END
                WHERE serviceman_id = ?
                `,
                [servicemanId]
            );


            /*
            --------------------------------------------
            Add service history
            --------------------------------------------
            */

            await connection.query(
                `
                INSERT INTO service_history
                (
                    request_id,
                    user_id,
                    serviceman_id,
                    charge
                )
                VALUES (?, ?, ?, ?)
                `,
                [
                    request.request_id,
                    request.user_id,
                    servicemanId,
                    request.charge
                ]
            );

            await connection.commit();

            res.json({
                message:
                    'Job completed successfully'
            });

        } catch (error) {

            await connection.rollback();

            console.error(
                'Complete job error:',
                error
            );

            res.status(500).json({
                message:
                    'Server error while completing job'
            });

        } finally {
            connection.release();
        }
    }
);


/*
====================================================
SUBMIT LEAVE REQUEST
====================================================
*/
router.post(
    '/leave-requests',
    async (req, res) => {

        try {
            const {
                servicemanId,
                start_date,
                end_date,
                reason
            } = req.body;

            if (
                !servicemanId ||
                !start_date ||
                !end_date
            ) {
                return res.status(400).json({
                    message:
                        'Serviceman ID, start date and end date are required'
                });
            }

            if (
                new Date(start_date) >
                new Date(end_date)
            ) {
                return res.status(400).json({
                    message:
                        'End date cannot be before start date'
                });
            }

            const [servicemen] = await db.query(
                `
                SELECT serviceman_id
                FROM servicemen
                WHERE serviceman_id = ?
                `,
                [servicemanId]
            );

            if (servicemen.length === 0) {
                return res.status(404).json({
                    message:
                        'Serviceman not found'
                });
            }

            const [result] = await db.query(
                `
                INSERT INTO leave_requests
                (
                    serviceman_id,
                    start_date,
                    end_date,
                    reason
                )
                VALUES (?, ?, ?, ?)
                `,
                [
                    servicemanId,
                    start_date,
                    end_date,
                    reason || null
                ]
            );

            res.status(201).json({
                message:
                    'Leave request submitted successfully',

                leave_id:
                    result.insertId
            });

        } catch (error) {

            console.error(
                'Leave request error:',
                error
            );

            res.status(500).json({
                message:
                    'Server error while submitting leave request'
            });
        }
    }
);


/*
====================================================
GET SERVICEMAN LEAVE REQUESTS
====================================================
*/
router.get(
    '/leave-requests/:servicemanId',
    async (req, res) => {

        try {

            const {
                servicemanId
            } = req.params;

            const [leaves] = await db.query(
                `
                SELECT
                    leave_id,
                    start_date,
                    end_date,
                    reason,
                    status,
                    created_at

                FROM leave_requests

                WHERE serviceman_id = ?

                ORDER BY created_at DESC
                `,
                [servicemanId]
            );

            res.json(leaves);

        } catch (error) {

            console.error(
                'Get leave requests error:',
                error
            );

            res.status(500).json({
                message: 'Server error'
            });
        }
    }
);


module.exports = router;