const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const db = require('../db');

const router = express.Router();


// =====================================================
// USER SIGNUP
// =====================================================

router.post('/signup', async (req, res) => {

    try {

        const {
            name,
            email,
            phone,
            password,
            default_address
        } = req.body;


        // Check required fields
        if (!name || !email || !phone || !password) {

            return res.status(400).json({
                message: 'Name, email, phone and password are required'
            });

        }


        // Check whether email already exists
        const [existingEmail] = await db.query(
            'SELECT user_id FROM users WHERE email = ?',
            [email]
        );

        if (existingEmail.length > 0) {

            return res.status(400).json({
                message: 'Email already registered'
            });

        }


        // Check whether phone already exists
        const [existingPhone] = await db.query(
            'SELECT user_id FROM users WHERE phone = ?',
            [phone]
        );

        if (existingPhone.length > 0) {

            return res.status(400).json({
                message: 'Phone number already registered'
            });

        }


        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);


        // Insert user
        const [result] = await db.query(
            `INSERT INTO users
            (name, email, phone, password, role, default_address)
            VALUES (?, ?, ?, ?, 'user', ?)`,
            [
                name,
                email,
                phone,
                hashedPassword,
                default_address || null
            ]
        );


        res.status(201).json({

            message: 'User registered successfully',

            user: {
                user_id: result.insertId,
                name: name,
                email: email,
                phone: phone,
                role: 'user'
            }

        });

    } catch (error) {

        console.error('Signup error:', error);

        res.status(500).json({
            message: 'Server error during signup'
        });

    }

});


// =====================================================
// LOGIN
// =====================================================

router.post('/login', async (req, res) => {

    try {

        const {
            email,
            password
        } = req.body;


        // Check input
        if (!email || !password) {

            return res.status(400).json({
                message: 'Email and password are required'
            });

        }


        // =================================================
        // CHECK ADMIN / NORMAL USER
        // =================================================

        const [users] = await db.query(
            'SELECT * FROM users WHERE email = ?',
            [email]
        );


        if (users.length > 0) {

            const user = users[0];


            // Check password
            const passwordMatch = await bcrypt.compare(
                password,
                user.password
            );


            if (!passwordMatch) {

                return res.status(401).json({
                    message: 'Invalid email or password'
                });

            }


            // Create JWT
            const token = jwt.sign(
                {
                    id: user.user_id,
                    role: user.role,
                    name: user.name
                },
                process.env.JWT_SECRET,
                {
                    expiresIn: '1d'
                }
            );


            return res.json({

                message: 'Login successful',

                token: token,

                user: {
                    id: user.user_id,
                    name: user.name,
                    email: user.email,
                    phone: user.phone,
                    role: user.role
                }

            });

        }


        // =================================================
        // CHECK SERVICEMAN
        // =================================================

        const [servicemen] = await db.query(
            'SELECT * FROM servicemen WHERE email = ?',
            [email]
        );


        if (servicemen.length > 0) {

            const serviceman = servicemen[0];


            // Check password
            const passwordMatch = await bcrypt.compare(
                password,
                serviceman.password
            );


            if (!passwordMatch) {

                return res.status(401).json({
                    message: 'Invalid email or password'
                });

            }


            // Create JWT
            const token = jwt.sign(
                {
                    id: serviceman.serviceman_id,
                    role: 'serviceman',
                    name: serviceman.name
                },
                process.env.JWT_SECRET,
                {
                    expiresIn: '1d'
                }
            );


            return res.json({

                message: 'Login successful',

                token: token,

                user: {
                    id: serviceman.serviceman_id,
                    name: serviceman.name,
                    email: serviceman.email,
                    phone: serviceman.phone,
                    role: 'serviceman'
                }

            });

        }


        // =================================================
        // ACCOUNT NOT FOUND
        // =================================================

        return res.status(401).json({
            message: 'Invalid email or password'
        });


    } catch (error) {

        console.error('Login error:', error);

        res.status(500).json({
            message: 'Server error during login'
        });

    }

});


module.exports = router;