const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db');

const router = express.Router();


// =====================================================
// ADMIN DASHBOARD STATISTICS
// =====================================================

router.get('/dashboard-stats', async (req, res) => {

    try {

        const [users] = await db.query(`
            SELECT COUNT(*) AS total
            FROM users
            WHERE role = 'user'
        `);

        const [requests] = await db.query(`
            SELECT COUNT(*) AS total
            FROM service_requests
        `);

        const [servicemen] = await db.query(`
            SELECT COUNT(*) AS total
            FROM servicemen
            WHERE status = 'Active'
        `);

        const [pending] = await db.query(`
            SELECT COUNT(*) AS total
            FROM service_requests
            WHERE status = 'Pending'
        `);

        const [completed] = await db.query(`
            SELECT COUNT(*) AS total
            FROM service_requests
            WHERE status = 'Completed'
        `);

        const [available] = await db.query(`
            SELECT COUNT(*) AS total
            FROM servicemen
            WHERE status = 'Active'
            AND availability = TRUE
        `);

        res.json({

            totalUsers: users[0].total,

            totalRequests: requests[0].total,

            totalServicemen: servicemen[0].total,

            pendingRequests: pending[0].total,

            completedRequests: completed[0].total,

            availableServicemen: available[0].total

        });

    } catch (error) {

        console.error(
            'Dashboard stats error:',
            error
        );

        res.status(500).json({
            message:
                'Failed to load dashboard statistics'
        });

    }

});


// =====================================================
// GET ALL SERVICE REQUESTS
// =====================================================

router.get('/service-requests', async (req, res) => {

    try {

        const [requests] = await db.query(`

            SELECT

                sr.request_id,

                sr.user_id,

                u.name AS user_name,

                u.email AS user_email,

                u.phone AS user_phone,

                sr.service_id,

                s.service_name,

                s.skill_required,

                sr.address_id,

                a.address,

                a.latitude,

                a.longitude,

                sr.description,

                sr.priority,

                sr.status,

                sr.charge,

                sr.created_at

            FROM service_requests sr

            INNER JOIN users u
                ON sr.user_id = u.user_id

            INNER JOIN services s
                ON sr.service_id = s.service_id

            INNER JOIN addresses a
                ON sr.address_id = a.address_id

            ORDER BY

                CASE sr.priority

                    WHEN 'Emergency' THEN 1
                    WHEN 'High' THEN 2
                    WHEN 'Medium' THEN 3
                    WHEN 'Low' THEN 4

                END,

                sr.created_at DESC

        `);

        res.json(requests);

    } catch (error) {

        console.error(
            'Get admin service requests error:',
            error
        );

        res.status(500).json({
            message:
                'Failed to load service requests'
        });

    }

});


// =====================================================
// GET SINGLE SERVICE REQUEST
// =====================================================

router.get(
    '/service-requests/:requestId',
    async (req, res) => {

        try {

            const requestId =
                req.params.requestId;

            const [requests] = await db.query(`

                SELECT

                    sr.request_id,

                    sr.user_id,

                    u.name AS user_name,

                    u.email AS user_email,

                    u.phone AS user_phone,

                    sr.service_id,

                    s.service_name,

                    s.skill_required,

                    sr.address_id,

                    a.address,

                    a.latitude,

                    a.longitude,

                    sr.description,

                    sr.priority,

                    sr.status,

                    sr.charge,

                    sr.created_at

                FROM service_requests sr

                INNER JOIN users u
                    ON sr.user_id = u.user_id

                INNER JOIN services s
                    ON sr.service_id = s.service_id

                INNER JOIN addresses a
                    ON sr.address_id = a.address_id

                WHERE sr.request_id = ?

            `, [requestId]);

            if (requests.length === 0) {

                return res.status(404).json({
                    message:
                        'Service request not found'
                });

            }

            res.json(requests[0]);

        } catch (error) {

            console.error(
                'Get single request error:',
                error
            );

            res.status(500).json({
                message:
                    'Failed to load service request'
            });

        }

    }
);


// =====================================================
// ACCEPT SERVICE REQUEST
// =====================================================

router.put(
    '/service-requests/:requestId/accept',
    async (req, res) => {

        try {

            const requestId =
                req.params.requestId;

            const [requests] = await db.query(
                `SELECT
                    request_id,
                    status
                 FROM service_requests
                 WHERE request_id = ?`,
                [requestId]
            );

            if (requests.length === 0) {

                return res.status(404).json({
                    message:
                        'Service request not found'
                });

            }

            const request =
                requests[0];

            if (request.status !== 'Pending') {

                return res.status(400).json({
                    message:
                        `Request cannot be accepted because its current status is ${request.status}`
                });

            }

            await db.query(
                `UPDATE service_requests
                 SET status = 'Accepted'
                 WHERE request_id = ?`,
                [requestId]
            );

            res.json({
                message:
                    'Service request accepted successfully'
            });

        } catch (error) {

            console.error(
                'Accept request error:',
                error
            );

            res.status(500).json({
                message:
                    'Failed to accept service request'
            });

        }

    }
);


// =====================================================
// REJECT SERVICE REQUEST
// =====================================================

router.put(
    '/service-requests/:requestId/reject',
    async (req, res) => {

        try {

            const requestId =
                req.params.requestId;

            const [requests] = await db.query(
                `SELECT
                    request_id,
                    status
                 FROM service_requests
                 WHERE request_id = ?`,
                [requestId]
            );

            if (requests.length === 0) {

                return res.status(404).json({
                    message:
                        'Service request not found'
                });

            }

            const request =
                requests[0];

            if (request.status !== 'Pending') {

                return res.status(400).json({
                    message:
                        `Request cannot be rejected because its current status is ${request.status}`
                });

            }

            await db.query(
                `UPDATE service_requests
                 SET status = 'Rejected'
                 WHERE request_id = ?`,
                [requestId]
            );

            res.json({
                message:
                    'Service request rejected successfully'
            });

        } catch (error) {

            console.error(
                'Reject request error:',
                error
            );

            res.status(500).json({
                message:
                    'Failed to reject service request'
            });

        }

    }
);


// =====================================================
// UPDATE REQUEST STATUS
// =====================================================

router.put(
    '/service-requests/:requestId/status',
    async (req, res) => {

        try {

            const requestId =
                req.params.requestId;

            const {
                status
            } = req.body;

            const allowedStatuses = [

                'Pending',
                'Accepted',
                'Rejected',
                'Assigned',
                'In Progress',
                'Completed',
                'Cancelled'

            ];

            if (!allowedStatuses.includes(status)) {

                return res.status(400).json({
                    message:
                        'Invalid request status'
                });

            }

            const [requests] = await db.query(
                `SELECT request_id
                 FROM service_requests
                 WHERE request_id = ?`,
                [requestId]
            );

            if (requests.length === 0) {

                return res.status(404).json({
                    message:
                        'Service request not found'
                });

            }

            await db.query(
                `UPDATE service_requests
                 SET status = ?
                 WHERE request_id = ?`,
                [
                    status,
                    requestId
                ]
            );

            res.json({

                message:
                    'Request status updated successfully',

                status:
                    status

            });

        } catch (error) {

            console.error(
                'Update request status error:',
                error
            );

            res.status(500).json({
                message:
                    'Failed to update request status'
            });

        }

    }
);


// =====================================================
// SERVICEMAN MANAGEMENT
// =====================================================


// =====================================================
// GET ALL SERVICEMEN
// =====================================================

router.get('/servicemen', async (req, res) => {

    try {

        const [servicemen] = await db.query(`

            SELECT

                serviceman_id,
                name,
                phone,
                email,
                skill,
                availability,
                current_workload,
                status,
                created_at

            FROM servicemen

            ORDER BY serviceman_id DESC

        `);

        res.json(servicemen);

    } catch (error) {

        console.error(
            'Get servicemen error:',
            error
        );

        res.status(500).json({
            message:
                'Failed to load servicemen'
        });

    }

});


// =====================================================
// GET AVAILABLE SERVICEMEN
//
// Optional:
// /api/admin/servicemen/available?skill=AC%20Technician
//
// Results are ordered by workload so that the
// serviceman with the lowest workload appears first.
// =====================================================

router.get(
    '/servicemen/available',
    async (req, res) => {

        try {

            const skill =
                req.query.skill;


            let query = `

                SELECT

                    serviceman_id,
                    name,
                    phone,
                    email,
                    skill,
                    availability,
                    current_workload,
                    status

                FROM servicemen

                WHERE status = 'Active'

                AND availability = TRUE

            `;


            const params = [];


            if (skill) {

                query += `

                    AND LOWER(skill) =
                        LOWER(?)

                `;

                params.push(skill);

            }


            query += `

                ORDER BY
                    current_workload ASC,
                    serviceman_id ASC

            `;


            const [servicemen] =
                await db.query(
                    query,
                    params
                );


            res.json(servicemen);


        } catch (error) {

            console.error(
                'Get available servicemen error:',
                error
            );


            res.status(500).json({

                message:
                    'Failed to load available servicemen'

            });

        }

    }
);


// =====================================================
// GET SINGLE SERVICEMAN
// =====================================================

router.get(
    '/servicemen/:servicemanId',
    async (req, res) => {

        try {

            const servicemanId =
                req.params.servicemanId;

            const [servicemen] =
                await db.query(
                    `SELECT

                        serviceman_id,
                        name,
                        phone,
                        email,
                        skill,
                        availability,
                        current_workload,
                        status,
                        created_at

                     FROM servicemen

                     WHERE serviceman_id = ?`,
                    [servicemanId]
                );

            if (servicemen.length === 0) {

                return res.status(404).json({
                    message:
                        'Serviceman not found'
                });

            }

            res.json(servicemen[0]);

        } catch (error) {

            console.error(
                'Get serviceman error:',
                error
            );

            res.status(500).json({
                message:
                    'Failed to load serviceman'
            });

        }

    }
);


// =====================================================
// ADD SERVICEMAN
// =====================================================

router.post('/servicemen', async (req, res) => {

    try {

        const {
            name,
            phone,
            email,
            password,
            skill
        } = req.body;


        if (
            !name ||
            !phone ||
            !email ||
            !password ||
            !skill
        ) {

            return res.status(400).json({
                message:
                    'Name, phone, email, password and skill are required'
            });

        }


        const [existingPhone] =
            await db.query(
                `SELECT serviceman_id
                 FROM servicemen
                 WHERE phone = ?`,
                [phone]
            );


        if (existingPhone.length > 0) {

            return res.status(400).json({
                message:
                    'Phone number already registered'
            });

        }


        const [existingEmail] =
            await db.query(
                `SELECT serviceman_id
                 FROM servicemen
                 WHERE email = ?`,
                [email]
            );


        if (existingEmail.length > 0) {

            return res.status(400).json({
                message:
                    'Email already registered'
            });

        }


        const [userEmail] =
            await db.query(
                `SELECT user_id
                 FROM users
                 WHERE email = ?`,
                [email]
            );


        if (userEmail.length > 0) {

            return res.status(400).json({
                message:
                    'This email is already used by another account'
            });

        }


        const hashedPassword =
            await bcrypt.hash(
                password,
                10
            );


        const [result] =
            await db.query(
                `INSERT INTO servicemen
                (
                    name,
                    phone,
                    email,
                    password,
                    skill,
                    availability,
                    current_workload,
                    status
                )
                VALUES (?, ?, ?, ?, ?, TRUE, 0, 'Active')`,
                [
                    name.trim(),
                    phone.trim(),
                    email.trim(),
                    hashedPassword,
                    skill.trim()
                ]
            );


        res.status(201).json({

            message:
                'Serviceman added successfully',

            serviceman: {

                serviceman_id:
                    result.insertId,

                name:
                    name.trim(),

                phone:
                    phone.trim(),

                email:
                    email.trim(),

                skill:
                    skill.trim(),

                availability:
                    true,

                current_workload:
                    0,

                status:
                    'Active'

            }

        });

    } catch (error) {

        console.error(
            'Add serviceman error:',
            error
        );

        res.status(500).json({
            message:
                'Failed to add serviceman'
        });

    }

});


// =====================================================
// UPDATE SERVICEMAN
// =====================================================

router.put(
    '/servicemen/:servicemanId',
    async (req, res) => {

        try {

            const servicemanId =
                req.params.servicemanId;

            const {
                name,
                phone,
                email,
                skill,
                availability,
                status
            } = req.body;


            if (
                !name ||
                !phone ||
                !email ||
                !skill
            ) {

                return res.status(400).json({
                    message:
                        'Name, phone, email and skill are required'
                });

            }


            const [existing] =
                await db.query(
                    `SELECT serviceman_id
                     FROM servicemen
                     WHERE serviceman_id = ?`,
                    [servicemanId]
                );


            if (existing.length === 0) {

                return res.status(404).json({
                    message:
                        'Serviceman not found'
                });

            }


            const [duplicatePhone] =
                await db.query(
                    `SELECT serviceman_id
                     FROM servicemen
                     WHERE phone = ?
                     AND serviceman_id != ?`,
                    [
                        phone,
                        servicemanId
                    ]
                );


            if (duplicatePhone.length > 0) {

                return res.status(400).json({
                    message:
                        'Phone number already used'
                });

            }


            const [duplicateEmail] =
                await db.query(
                    `SELECT serviceman_id
                     FROM servicemen
                     WHERE email = ?
                     AND serviceman_id != ?`,
                    [
                        email,
                        servicemanId
                    ]
                );


            if (duplicateEmail.length > 0) {

                return res.status(400).json({
                    message:
                        'Email already used'
                });

            }


            const finalStatus =
                status || 'Active';


            if (
                finalStatus !== 'Active' &&
                finalStatus !== 'Inactive'
            ) {

                return res.status(400).json({
                    message:
                        'Invalid serviceman status'
                });

            }


            await db.query(
                `UPDATE servicemen

                 SET

                    name = ?,
                    phone = ?,
                    email = ?,
                    skill = ?,
                    availability = ?,
                    status = ?

                 WHERE serviceman_id = ?`,
                [
                    name.trim(),
                    phone.trim(),
                    email.trim(),
                    skill.trim(),
                    availability === true,
                    finalStatus,
                    servicemanId
                ]
            );


            res.json({
                message:
                    'Serviceman updated successfully'
            });

        } catch (error) {

            console.error(
                'Update serviceman error:',
                error
            );

            res.status(500).json({
                message:
                    'Failed to update serviceman'
            });

        }

    }
);


// =====================================================
// UPDATE SERVICEMAN AVAILABILITY
// =====================================================

router.put(
    '/servicemen/:servicemanId/availability',
    async (req, res) => {

        try {

            const servicemanId =
                req.params.servicemanId;

            const {
                availability
            } = req.body;


            if (
                typeof availability !== 'boolean'
            ) {

                return res.status(400).json({
                    message:
                        'Availability must be true or false'
                });

            }


            const [result] =
                await db.query(
                    `UPDATE servicemen

                     SET availability = ?

                     WHERE serviceman_id = ?`,
                    [
                        availability,
                        servicemanId
                    ]
                );


            if (
                result.affectedRows === 0
            ) {

                return res.status(404).json({
                    message:
                        'Serviceman not found'
                });

            }


            res.json({

                message:
                    'Availability updated successfully',

                availability:
                    availability

            });

        } catch (error) {

            console.error(
                'Availability error:',
                error
            );

            res.status(500).json({
                message:
                    'Failed to update availability'
            });

        }

    }
);


// =====================================================
// ACTIVATE SERVICEMAN
// =====================================================

router.put(
    '/servicemen/:servicemanId/activate',
    async (req, res) => {

        try {

            const servicemanId =
                req.params.servicemanId;


            const [result] =
                await db.query(
                    `UPDATE servicemen

                     SET
                        status = 'Active',
                        availability = TRUE

                     WHERE serviceman_id = ?`,
                    [servicemanId]
                );


            if (
                result.affectedRows === 0
            ) {

                return res.status(404).json({
                    message:
                        'Serviceman not found'
                });

            }


            res.json({
                message:
                    'Serviceman activated successfully'
            });

        } catch (error) {

            console.error(
                'Activate serviceman error:',
                error
            );

            res.status(500).json({
                message:
                    'Failed to activate serviceman'
            });

        }

    }
);


// =====================================================
// DEACTIVATE SERVICEMAN
// =====================================================

router.put(
    '/servicemen/:servicemanId/deactivate',
    async (req, res) => {

        try {

            const servicemanId =
                req.params.servicemanId;


            const [result] =
                await db.query(
                    `UPDATE servicemen

                     SET
                        status = 'Inactive',
                        availability = FALSE

                     WHERE serviceman_id = ?`,
                    [servicemanId]
                );


            if (
                result.affectedRows === 0
            ) {

                return res.status(404).json({
                    message:
                        'Serviceman not found'
                });

            }


            res.json({
                message:
                    'Serviceman deactivated successfully'
            });

        } catch (error) {

            console.error(
                'Deactivate serviceman error:',
                error
            );

            res.status(500).json({
                message:
                    'Failed to deactivate serviceman'
            });

        }

    }
);


// =====================================================
// ASSIGN SERVICE REQUEST TO SERVICEMAN
// =====================================================
//
// Body:
// {
//     "serviceman_id": 1
// }
//
// The system checks:
//
// 1. Request exists
// 2. Request is not already assigned
// 3. Serviceman exists
// 4. Serviceman is Active
// 5. Serviceman is Available
// 6. Serviceman has the required skill
//
// Then:
//
// - Creates assignment
// - Increases workload
// - Changes request status to Assigned
//
// =====================================================

router.put(
    '/service-requests/:requestId/assign',
    async (req, res) => {

        const connection =
            await db.getConnection();

        try {

            const requestId =
                req.params.requestId;

            const {
                serviceman_id
            } = req.body;


            if (!serviceman_id) {

                connection.release();

                return res.status(400).json({
                    message:
                        'Serviceman ID is required'
                });

            }


            await connection.beginTransaction();


            // =================================================
            // GET REQUEST
            // =================================================

            const [requests] =
                await connection.query(
                    `SELECT

                        sr.request_id,
                        sr.status,
                        s.skill_required

                     FROM service_requests sr

                     INNER JOIN services s
                        ON sr.service_id = s.service_id

                     WHERE sr.request_id = ?

                     FOR UPDATE`,
                    [requestId]
                );


            if (requests.length === 0) {

                await connection.rollback();
                connection.release();

                return res.status(404).json({
                    message:
                        'Service request not found'
                });

            }


            const request =
                requests[0];


            // Only Accepted requests should be assigned.
            if (
                request.status !== 'Accepted'
            ) {

                await connection.rollback();
                connection.release();

                return res.status(400).json({

                    message:
                        `Only Accepted requests can be assigned. Current status: ${request.status}`

                });

            }


            // =================================================
            // GET SERVICEMAN
            // =================================================

            const [servicemen] =
                await connection.query(
                    `SELECT

                        serviceman_id,
                        name,
                        skill,
                        availability,
                        current_workload,
                        status

                     FROM servicemen

                     WHERE serviceman_id = ?

                     FOR UPDATE`,
                    [serviceman_id]
                );


            if (servicemen.length === 0) {

                await connection.rollback();
                connection.release();

                return res.status(404).json({
                    message:
                        'Serviceman not found'
                });

            }


            const serviceman =
                servicemen[0];


            // =================================================
            // CHECK ACTIVE
            // =================================================

            if (
                serviceman.status !== 'Active'
            ) {

                await connection.rollback();
                connection.release();

                return res.status(400).json({
                    message:
                        'Selected serviceman is inactive'
                });

            }


            // =================================================
            // CHECK AVAILABILITY
            // =================================================

            if (
                !serviceman.availability
            ) {

                await connection.rollback();
                connection.release();

                return res.status(400).json({
                    message:
                        'Selected serviceman is currently unavailable'
                });

            }


            // =================================================
            // CHECK SKILL
            // =================================================

            if (
                serviceman.skill.trim().toLowerCase() !==
                request.skill_required.trim().toLowerCase()
            ) {

                await connection.rollback();
                connection.release();

                return res.status(400).json({

                    message:
                        `Skill mismatch. Request requires "${request.skill_required}" but selected serviceman has "${serviceman.skill}"`

                });

            }


            // =================================================
            // CREATE ASSIGNMENT
            // =================================================

            const [assignment] =
                await connection.query(
                    `INSERT INTO assignments
                    (
                        request_id,
                        serviceman_id
                    )
                    VALUES (?, ?)`,
                    [
                        requestId,
                        serviceman_id
                    ]
                );


            // =================================================
            // INCREASE WORKLOAD
            // =================================================

            await connection.query(
                `UPDATE servicemen

                 SET current_workload =
                     current_workload + 1

                 WHERE serviceman_id = ?`,
                [serviceman_id]
            );


            // =================================================
            // UPDATE REQUEST STATUS
            // =================================================

            await connection.query(
                `UPDATE service_requests

                 SET status = 'Assigned'

                 WHERE request_id = ?`,
                [requestId]
            );


            await connection.commit();

            connection.release();


            res.json({

                message:
                    'Service request assigned successfully',

                assignment: {

                    assignment_id:
                        assignment.insertId,

                    request_id:
                        Number(requestId),

                    serviceman_id:
                        Number(serviceman_id),

                    serviceman_name:
                        serviceman.name,

                    skill:
                        serviceman.skill,

                    status:
                        'Assigned'

                }

            });


        } catch (error) {

            await connection.rollback();

            connection.release();

            console.error(
                'Assign request error:',
                error
            );


            // Duplicate assignment
            if (
                error.code === 'ER_DUP_ENTRY'
            ) {

                return res.status(400).json({

                    message:
                        'This service request is already assigned'

                });

            }


            res.status(500).json({

                message:
                    'Failed to assign service request'

            });

        }

    }
);


// =====================================================
// GET ASSIGNMENT FOR A REQUEST
// =====================================================

router.get(
    '/service-requests/:requestId/assignment',
    async (req, res) => {

        try {

            const requestId =
                req.params.requestId;


            const [assignments] =
                await db.query(
                    `SELECT

                        a.assignment_id,

                        a.request_id,

                        a.serviceman_id,

                        sm.name AS serviceman_name,

                        sm.phone AS serviceman_phone,

                        sm.email AS serviceman_email,

                        sm.skill AS serviceman_skill,

                        a.assigned_at,

                        a.started_at,

                        a.completed_at

                     FROM assignments a

                     INNER JOIN servicemen sm
                        ON a.serviceman_id =
                           sm.serviceman_id

                     WHERE a.request_id = ?

                     ORDER BY a.assignment_id DESC

                     LIMIT 1`,
                    [requestId]
                );


            if (assignments.length === 0) {

                return res.status(404).json({

                    message:
                        'No assignment found for this request'

                });

            }


            res.json(assignments[0]);


        } catch (error) {

            console.error(
                'Get assignment error:',
                error
            );


            res.status(500).json({

                message:
                    'Failed to load assignment'

            });

        }

    }
);


// =====================================================
// LEAVE REQUEST MANAGEMENT
// =====================================================


// =====================================================
// GET ALL LEAVE REQUESTS
// =====================================================
//
// Returns all serviceman leave requests with
// serviceman details.
// =====================================================

router.get(
    '/leave-requests',
    async (req, res) => {

        try {

            const [leaves] =
                await db.query(
                    `SELECT

                        lr.leave_id,

                        lr.serviceman_id,

                        sm.name AS serviceman_name,

                        sm.phone AS serviceman_phone,

                        sm.email AS serviceman_email,

                        sm.skill AS serviceman_skill,

                        lr.start_date,

                        lr.end_date,

                        lr.reason,

                        lr.status,

                        lr.created_at

                     FROM leave_requests lr

                     INNER JOIN servicemen sm
                        ON lr.serviceman_id =
                           sm.serviceman_id

                     ORDER BY

                        CASE lr.status

                            WHEN 'Pending' THEN 1
                            WHEN 'Approved' THEN 2
                            WHEN 'Rejected' THEN 3

                        END,

                        lr.start_date ASC,

                        lr.created_at DESC`
                );


            res.json(leaves);

        } catch (error) {

            console.error(
                'Get leave requests error:',
                error
            );

            res.status(500).json({

                message:
                    'Failed to load leave requests'

            });

        }

    }
);


// =====================================================
// GET SINGLE LEAVE REQUEST
// =====================================================

router.get(
    '/leave-requests/:leaveId',
    async (req, res) => {

        try {

            const leaveId =
                req.params.leaveId;


            const [leaves] =
                await db.query(
                    `SELECT

                        lr.leave_id,

                        lr.serviceman_id,

                        sm.name AS serviceman_name,

                        sm.phone AS serviceman_phone,

                        sm.email AS serviceman_email,

                        sm.skill AS serviceman_skill,

                        lr.start_date,

                        lr.end_date,

                        lr.reason,

                        lr.status,

                        lr.created_at

                     FROM leave_requests lr

                     INNER JOIN servicemen sm
                        ON lr.serviceman_id =
                           sm.serviceman_id

                     WHERE lr.leave_id = ?`,
                    [leaveId]
                );


            if (leaves.length === 0) {

                return res.status(404).json({

                    message:
                        'Leave request not found'

                });

            }


            res.json(leaves[0]);

        } catch (error) {

            console.error(
                'Get single leave request error:',
                error
            );

            res.status(500).json({

                message:
                    'Failed to load leave request'

            });

        }

    }
);


// =====================================================
// APPROVE LEAVE REQUEST
// =====================================================
//
// When leave is approved:
//
// 1. Leave status becomes Approved
// 2. Serviceman becomes unavailable
//
// =====================================================

router.put(
    '/leave-requests/:leaveId/approve',
    async (req, res) => {

        const connection =
            await db.getConnection();

        try {

            const leaveId =
                req.params.leaveId;


            await connection.beginTransaction();


            // =================================================
            // GET LEAVE REQUEST
            // =================================================

            const [leaves] =
                await connection.query(
                    `SELECT

                        leave_id,
                        serviceman_id,
                        start_date,
                        end_date,
                        status

                     FROM leave_requests

                     WHERE leave_id = ?

                     FOR UPDATE`,
                    [leaveId]
                );


            if (leaves.length === 0) {

                await connection.rollback();
                connection.release();

                return res.status(404).json({

                    message:
                        'Leave request not found'

                });

            }


            const leave =
                leaves[0];


            // =================================================
            // CHECK CURRENT STATUS
            // =================================================

            if (
                leave.status !== 'Pending'
            ) {

                await connection.rollback();
                connection.release();

                return res.status(400).json({

                    message:
                        `Leave request cannot be approved because its current status is ${leave.status}`

                });

            }


            // =================================================
            // CHECK FOR OVERLAPPING APPROVED LEAVE
            // =================================================

            const [overlappingLeave] =
                await connection.query(
                    `SELECT leave_id

                     FROM leave_requests

                     WHERE serviceman_id = ?

                     AND status = 'Approved'

                     AND leave_id != ?

                     AND start_date <= ?

                     AND end_date >= ?

                     LIMIT 1`,
                    [
                        leave.serviceman_id,
                        leaveId,
                        leave.end_date,
                        leave.start_date
                    ]
                );


            if (
                overlappingLeave.length > 0
            ) {

                await connection.rollback();
                connection.release();

                return res.status(400).json({

                    message:
                        'This serviceman already has an approved leave overlapping these dates'

                });

            }


            // =================================================
            // CHECK SERVICEMAN
            // =================================================

            const [servicemen] =
                await connection.query(
                    `SELECT

                        serviceman_id,
                        name,
                        availability,
                        status

                     FROM servicemen

                     WHERE serviceman_id = ?

                     FOR UPDATE`,
                    [leave.serviceman_id]
                );


            if (servicemen.length === 0) {

                await connection.rollback();
                connection.release();

                return res.status(404).json({

                    message:
                        'Serviceman not found'

                });

            }


            const serviceman =
                servicemen[0];


            if (
                serviceman.status !== 'Active'
            ) {

                await connection.rollback();
                connection.release();

                return res.status(400).json({

                    message:
                        'Inactive serviceman leave cannot be approved'

                });

            }


            // =================================================
            // APPROVE LEAVE
            // =================================================

            await connection.query(
                `UPDATE leave_requests

                 SET status = 'Approved'

                 WHERE leave_id = ?`,
                [leaveId]
            );


            // =================================================
            // MAKE SERVICEMAN UNAVAILABLE
            // =================================================

            await connection.query(
                `UPDATE servicemen

                 SET availability = FALSE

                 WHERE serviceman_id = ?`,
                [leave.serviceman_id]
            );


            await connection.commit();

            connection.release();


            res.json({

                message:
                    'Leave request approved successfully',

                leave_id:
                    Number(leaveId),

                serviceman_id:
                    leave.serviceman_id,

                status:
                    'Approved'

            });


        } catch (error) {

            await connection.rollback();

            connection.release();

            console.error(
                'Approve leave error:',
                error
            );

            res.status(500).json({

                message:
                    'Failed to approve leave request'

            });

        }

    }
);


// =====================================================
// REJECT LEAVE REQUEST
// =====================================================
//
// When leave is rejected:
//
// 1. Leave status becomes Rejected
// 2. If there are no other approved leaves,
//    serviceman becomes available again.
// =====================================================

router.put(
    '/leave-requests/:leaveId/reject',
    async (req, res) => {

        const connection =
            await db.getConnection();

        try {

            const leaveId =
                req.params.leaveId;


            await connection.beginTransaction();


            // =================================================
            // GET LEAVE REQUEST
            // =================================================

            const [leaves] =
                await connection.query(
                    `SELECT

                        leave_id,
                        serviceman_id,
                        status

                     FROM leave_requests

                     WHERE leave_id = ?

                     FOR UPDATE`,
                    [leaveId]
                );


            if (leaves.length === 0) {

                await connection.rollback();
                connection.release();

                return res.status(404).json({

                    message:
                        'Leave request not found'

                });

            }


            const leave =
                leaves[0];


            // =================================================
            // CHECK CURRENT STATUS
            // =================================================

            if (
                leave.status !== 'Pending'
            ) {

                await connection.rollback();
                connection.release();

                return res.status(400).json({

                    message:
                        `Leave request cannot be rejected because its current status is ${leave.status}`

                });

            }


            // =================================================
            // REJECT LEAVE
            // =================================================

            await connection.query(
                `UPDATE leave_requests

                 SET status = 'Rejected'

                 WHERE leave_id = ?`,
                [leaveId]
            );


            // =================================================
            // CHECK OTHER APPROVED LEAVES
            // =================================================

            const [approvedLeaves] =
                await connection.query(
                    `SELECT leave_id

                     FROM leave_requests

                     WHERE serviceman_id = ?

                     AND status = 'Approved'

                     LIMIT 1`,
                    [leave.serviceman_id]
                );


            // =================================================
            // RESTORE AVAILABILITY
            // =================================================

            if (
                approvedLeaves.length === 0
            ) {

                await connection.query(
                    `UPDATE servicemen

                     SET availability = TRUE

                     WHERE serviceman_id = ?`,
                    [leave.serviceman_id]
                );

            }


            await connection.commit();

            connection.release();


            res.json({

                message:
                    'Leave request rejected successfully',

                leave_id:
                    Number(leaveId),

                serviceman_id:
                    leave.serviceman_id,

                status:
                    'Rejected'

            });


        } catch (error) {

            await connection.rollback();

            connection.release();

            console.error(
                'Reject leave error:',
                error
            );

            res.status(500).json({

                message:
                    'Failed to reject leave request'

            });

        }

    }
);


// =====================================================
// EXPORT ROUTER
// =====================================================

module.exports = router;