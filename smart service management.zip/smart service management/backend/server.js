const express = require('express');
const cors = require('cors');
const path = require('path');

require('dotenv').config();

const db = require('./db');

const authRoutes = require('./routes/auth');
const adminRoutes = require('./routes/admin');
const userRoutes = require('./routes/user');
const servicesRoutes = require('./routes/services');
const servicemanRoutes = require('./routes/serviceman');

const app = express();


// =====================================================
// MIDDLEWARE
// =====================================================

app.use(cors());

app.use(express.json());


// =====================================================
// SERVE FRONTEND
// =====================================================

app.use(
    express.static(
        path.join(__dirname, '../frontend')
    )
);


// =====================================================
// HOME
// =====================================================

app.get('/', (req, res) => {

    res.sendFile(
        path.join(
            __dirname,
            '../frontend/login.html'
        )
    );

});


// =====================================================
// HEALTH CHECK
// =====================================================

app.get('/api/health', async (req, res) => {

    try {

        const [result] = await db.query(
            'SELECT 1 AS connected'
        );

        res.json({

            status: 'OK',

            database: 'Connected',

            result: result[0]

        });

    } catch (error) {

        console.error(error);

        res.status(500).json({

            status: 'ERROR',

            database: 'Connection failed',

            error: error.message

        });

    }

});


// =====================================================
// AUTH ROUTES
// =====================================================

app.use(
    '/api/auth',
    authRoutes
);


// =====================================================
// ADMIN ROUTES
// =====================================================

app.use(
    '/api/admin',
    adminRoutes
);


// =====================================================
// USER ROUTES
// =====================================================

app.use(
    '/api/user',
    userRoutes
);


// =====================================================
// SERVICES ROUTES
// =====================================================

app.use(
    '/api/services',
    servicesRoutes
);


// =====================================================
// SERVICEMAN ROUTES
// =====================================================

app.use(
    '/api/serviceman',
    servicemanRoutes
);


// =====================================================
// START SERVER
// =====================================================

const PORT =
    process.env.PORT || 5000;


app.listen(
    PORT,
    () => {

        console.log(
            `Server running on http://localhost:${PORT}`
        );

    }
);